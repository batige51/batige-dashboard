import { NextResponse } from "next/server";
import { PrismaClient } from "@prisma/client";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

const prisma = new PrismaClient();

/**
 * POST /api/devis/deduction
 * { fromMarcheId: number, toMarcheId: number, description: string, montantHt: number }
 * -> crée 2 avenants libres : +montant sur toMarcheId, -montant sur fromMarcheId
 */
export async function POST(req: Request) {
  try {
    const body = await req.json();
    const fromMarcheId = Number(body?.fromMarcheId);
    const toMarcheId = Number(body?.toMarcheId);
    const description = String(body?.description || "").trim();
    const montant = Number(body?.montantHt || 0);

    if (!fromMarcheId || !toMarcheId || !description || !montant) {
      return NextResponse.json(
        { error: "fromMarcheId, toMarcheId, description, montantHt requis" },
        { status: 400 }
      );
    }
    if (fromMarcheId === toMarcheId) {
      return NextResponse.json({ error: "Marchés identiques" }, { status: 400 });
    }

    // petit helper pour créer un avenant "libre"
    async function createLibre(marcheId: number, delta: number) {
      const avenant = await prisma.avenantEntreprise.create({
        data: {
          marcheId,
          numero: `AV-${Date.now()}`,
          lines: {
            create: [
              {
                // on crée au passage une "ligne DPGF technique" si besoin
                dpgfLine: {
                  create: {
                    marcheId,
                    code: "--",
                    description,
                    unite: "U",
                    qty: 1,
                    unitPriceHt: Math.abs(delta),
                    totalHt: Math.abs(delta),
                    validatedHt: 0,
                    lot: "Avenants",
                  },
                },
                deltaHt: delta,
              },
            ],
          },
        },
        include: { lines: true },
      });
      return avenant;
    }

    // + sur l'entreprise qui a effectué
    const plus = await createLibre(toMarcheId, Math.abs(montant));
    // - sur l'entreprise à qui on déduit
    const moins = await createLibre(fromMarcheId, -Math.abs(montant));

    return NextResponse.json({ plus, moins }, { status: 201 });
  } catch (e: any) {
    return NextResponse.json({ error: e?.message || "Erreur" }, { status: 500 });
  }
}
