import { NextResponse } from "next/server";
import { PrismaClient } from "@prisma/client";
const prisma = new PrismaClient();

/**
 * DELETE /api/devis/:id/dpgf-lines/:lineId
 * Supprime UNE ligne DPGF du devis.
 */
export async function DELETE(
  _req: Request,
  { params }: { params: { id: string; lineId: string } }
) {
  const marcheId = Number(params.id);
  const lineId = Number(params.lineId);

  if (!marcheId || !lineId) {
    return NextResponse.json({ error: "Paramètres invalides" }, { status: 400 });
  }

  try {
    // Vérifier que la ligne appartient bien à ce devis
    const line = await prisma.dpgfLine.findUnique({ where: { id: lineId } });
    if (!line || line.marcheId !== marcheId) {
      return NextResponse.json({ error: "Ligne introuvable pour ce devis" }, { status: 404 });
    }

    await prisma.dpgfLine.delete({ where: { id: lineId } });
    return new NextResponse(null, { status: 204 }); // No Content
  } catch (e: any) {
    return NextResponse.json({ error: e?.message || "Delete failed" }, { status: 400 });
  }
}
