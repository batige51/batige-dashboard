"use client";

import { useEffect, useMemo, useState } from "react";
import { useParams, useRouter } from "next/navigation";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

type MarcheLite = { id: number; reference?: string | null; entreprise: { id: number; name: string } };
type MarcheFull  = MarcheLite & { projectId: number };

export default function DeductionPage() {
  const { id } = useParams<{ id: string }>();
  const marcheId = Number(id);
  const router = useRouter();

  const [me, setMe] = useState<MarcheFull | null>(null);
  const [others, setOthers] = useState<MarcheLite[]>([]);
  const [toMarcheId, setToMarcheId] = useState<number | null>(null);

  const [numero, setNumero] = useState("");
  const [description, setDescription] = useState("");
  const [montant, setMontant] = useState<string>("");

  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState<string | null>(null);

  // charge le marché courant et les marchés du même projet pour la liste déroulante
  useEffect(() => {
    (async () => {
      try {
        const r1 = await fetch(`/api/validation/marche/${marcheId}`, { cache: "no-store" });
        const j1 = await r1.json();
        const m = j1?.item as any;
        if (!m) return;

        setMe({ id: m.id, reference: m.reference, projectId: m.project.id, entreprise: m.entreprise });

        const r2 = await fetch(`/api/devis?projectId=${m.project.id}`, { cache: "no-store" });
        const j2 = await r2.json();
        const list: MarcheLite[] = (j2?.items || []).map((x: any) => ({
          id: x.id,
          reference: x.reference,
          entreprise: x.entreprise,
        }));
        setOthers(list.filter((x) => x.id !== m.id));
      } catch (_) {}
    })();
  }, [marcheId]);

  const canSubmit = useMemo(() => {
    const amt = Number(montant);
    return !!toMarcheId && description.trim().length > 0 && amt > 0 && !!me?.projectId;
  }, [toMarcheId, description, montant, me]);

  async function submit() {
    if (!canSubmit || !me) return;
    setBusy(true);
    setMsg(null);
    try {
      const r = await fetch(`/api/projects/${me.projectId}/deduction`, {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({
          fromMarcheId: me.id,
          toMarcheId,
          numero: numero.trim() || undefined,
          description: description.trim(),
          montantHt: Number(montant),
        }),
      });
      const j = await r.json();
      if (!r.ok) throw new Error(j?.error || "Échec création déduction");
      setMsg("Déduction enregistrée ✅");
      setTimeout(() => router.push(`/validation/${me.id}`), 800);
    } catch (e: any) {
      setMsg(e?.message || "Erreur inconnue");
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="max-w-3xl mx-auto px-4 py-6 space-y-6">
      <div className="flex items-center gap-3">
        <h1 className="text-2xl font-bold">Valider une déduction</h1>
        <div className="ml-auto">
          <Button variant="outline" onClick={() => router.push(`/validation/${marcheId}`)}>
            Retour
          </Button>
        </div>
      </div>

      <Card className="shadow-sm">
        <CardHeader>
          <CardTitle>Informations</CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="text-sm text-slate-700">
            Marché courant : <b>#{me?.id}</b> — Entreprise <b>{me?.entreprise?.name}</b> — Réf. <b>{me?.reference ?? "—"}</b>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            <div>
              <label className="block text-sm mb-1">Déduire À (entreprise)</label>
              <select
                className="w-full rounded border px-2 py-2"
                value={toMarcheId ?? ""}
                onChange={(e) => setToMarcheId(Number(e.target.value) || null)}
              >
                <option value="">— choisir un marché —</option>
                {others.map((m) => (
                  <option key={m.id} value={m.id}>
                    #{m.id} — {m.entreprise?.name} — {m.reference ?? "—"}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-sm mb-1">N° (optionnel)</label>
              <Input value={numero} onChange={(e) => setNumero(e.target.value)} placeholder="ex: DED-001" />
            </div>

            <div className="md:col-span-2">
              <label className="block text-sm mb-1">Description</label>
              <Input value={description} onChange={(e) => setDescription(e.target.value)} placeholder="Motif de la déduction" />
            </div>

            <div className="md:col-span-2">
              <label className="block text-sm mb-1">Montant HT</label>
              <Input type="number" step="0.01" value={montant} onChange={(e) => setMontant(e.target.value)} placeholder="ex: 1500" />
            </div>
          </div>

          <div className="flex items-center gap-3 pt-2">
            <Button onClick={submit} disabled={!canSubmit || busy}>
              {busy ? "Enregistrement…" : "Valider la déduction"}
            </Button>
            {msg && <span className="text-sm text-slate-600">{msg}</span>}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
